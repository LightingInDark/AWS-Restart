"""
Your module description
"""
print("Hello, World")
print(2 + 2)
print(4-2)
print(2*2)
print(4/2)

print("Python has three numeric types: int, float, and complex")

myValue =1
print(myValue)

print(type(myValue))

print(str(myValue) + " is of the data type " + str(type(myValue)))
